export class User{
    constructor(
        public selectedItem: string
    )
    {}
}